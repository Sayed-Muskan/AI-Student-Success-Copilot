# Credentials

See supabase_seed/LOGINS.md (principal + 15 faculty, created by supabase_seed/02_logins_and_profiles.sql).
Admins are the emails in backend/.env -> ADMIN_EMAILS. There are no built-in demo accounts.
