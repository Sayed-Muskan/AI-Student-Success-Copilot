import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click();
await page.waitForSelector('[data-testid="app-sidebar"]');
const info = await page.evaluate(() => {
  const aside = document.querySelector('[data-testid="app-sidebar"]');
  const wrapper = aside.parentElement;
  const cs = getComputedStyle(wrapper);
  return { wrapperClass: wrapper.className, transform: cs.transform, position: cs.position, width: cs.width, innerWidth: window.innerWidth };
});
console.log(JSON.stringify(info, null, 2));

});
