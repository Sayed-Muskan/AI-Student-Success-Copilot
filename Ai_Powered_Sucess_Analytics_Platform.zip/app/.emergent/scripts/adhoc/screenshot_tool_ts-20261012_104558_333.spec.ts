import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click();
await page.waitForSelector('[data-testid="app-shell"]');
const box1 = await page.getByTestId('mobile-menu-button').boundingBox();
const wrapper = await page.locator('div.fixed.inset-y-0.left-0.z-50').first();
const box2 = await wrapper.boundingBox();
console.log('menu button box', JSON.stringify(box1));
console.log('sidebar wrapper box', JSON.stringify(box2));
const el = await page.evaluate(([x,y]) => {
  const e = document.elementFromPoint(x,y);
  return e ? e.outerHTML.slice(0,200) : null;
}, [box1.x + box1.width/2, box1.y + box1.height/2]);
console.log('element at point', el);
await page.screenshot({ path: '.screenshots/mobile-closed.png' });

});
