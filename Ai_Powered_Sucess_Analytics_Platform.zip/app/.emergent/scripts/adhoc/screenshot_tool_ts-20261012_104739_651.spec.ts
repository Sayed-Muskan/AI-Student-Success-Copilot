import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const badResponses: string[] = [];
page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
page.on('response', (response) => { if (response.status() >= 400) badResponses.push(`${response.status()} ${response.url()}`); });
await page.setViewportSize({ width: 390, height: 844 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click({ force: true });
await page.getByTestId('dashboard-heading').waitFor({ timeout: 10000 });
const shell = page.getByTestId('mobile-sidebar-shell');
if ((await shell.getAttribute('data-open')) !== 'false') throw new Error('sidebar did not start closed');
const closedTransform = await shell.evaluate((element) => getComputedStyle(element).transform);
if (closedTransform === 'none') throw new Error('closed sidebar transform is none');
await page.getByTestId('mobile-menu-button').click();
if ((await shell.getAttribute('data-open')) !== 'true') throw new Error('sidebar did not open');
await page.screenshot({ path: 'mobile-sidebar-open-fixed.png', fullPage: false });
await page.getByTestId('sidebar-close-button').click();
if ((await shell.getAttribute('data-open')) !== 'false') throw new Error('sidebar did not close');
await page.getByTestId('mobile-menu-button').click();
await page.getByTestId('logout-button').click();
await page.waitForURL('**/login', { timeout: 10000 });
if (errors.length || badResponses.length) throw new Error(JSON.stringify({ errors, badResponses }));
console.log(JSON.stringify({ closedTransform, errors, badResponses, finalUrl: page.url() }));
});
