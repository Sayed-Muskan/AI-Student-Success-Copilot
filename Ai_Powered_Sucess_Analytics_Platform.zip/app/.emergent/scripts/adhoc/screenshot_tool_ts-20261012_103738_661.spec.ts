import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const badResponses: string[] = [];
page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
page.on('response', (response) => { if (response.status() >= 400) badResponses.push(`${response.status()} ${response.url()}`); });
await page.setViewportSize({ width: 1365, height: 768 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click({ force: true });
await page.getByTestId('dashboard-heading').waitFor({ timeout: 10000 });
await page.getByTestId('nav-Risk-signals-link').click({ force: true });
await page.getByTestId('risk-page-heading').waitFor({ timeout: 10000 });
await page.getByTestId('placement-risk-tab').click({ force: true });
await page.getByTestId('risk-department-filter').selectOption('CSE');
await page.locator('button[data-testid^="risk-student-"]').first().click({ force: true });
await page.waitForURL('**/students/*', { timeout: 10000 });
const student = await page.getByTestId('profile-student-name').innerText({ timeout: 10000 });
await page.setViewportSize({ width: 390, height: 844 });
await page.getByTestId('mobile-menu-button').click({ force: true });
await page.getByTestId('app-sidebar').waitFor({ timeout: 5000 });
await page.screenshot({ path: 'risk-signals-mobile-verified.png', fullPage: false });
if (errors.length || badResponses.length) throw new Error(JSON.stringify({ errors, badResponses }));
console.log(JSON.stringify({ errors, badResponses, finalUrl: page.url(), student }));
});
