import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  await page.setViewportSize({width:1280,height:720}); await page.goto('/',{waitUntil:'domcontentloaded'}); await page.screenshot({path:'/tmp/initial/home.png',fullPage:false});
});
