import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const badResponses: string[] = [];
page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
page.on('response', (response) => { if (response.status() >= 400) badResponses.push(`${response.status()} ${response.url()}`); });
await page.setViewportSize({ width: 1365, height: 768 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click({ force: true });
await page.getByTestId('dashboard-heading').waitFor();
await page.getByTestId('nav-Risk-signals-link').click({ force: true });
await page.getByTestId('risk-page-heading').waitFor();
await page.getByTestId('placement-risk-tab').click({ force: true });
await page.getByTestId('risk-department-filter').selectOption('CSE');
await page.getByTestId('risk-trend-chart').waitFor();
await page.locator('[data-testid^="risk-student-"]').first().click({ force: true });
await page.getByTestId('profile-student-name').waitFor();
await page.setViewportSize({ width: 390, height: 844 });
await page.getByTestId('mobile-menu-button').click({ force: true });
await page.getByTestId('app-sidebar').waitFor();
await page.screenshot({ path: 'risk-signals-mobile.png', fullPage: false });
console.log(JSON.stringify({ errors, badResponses, finalUrl: page.url(), student: await page.getByTestId('profile-student-name').innerText() }));
});
