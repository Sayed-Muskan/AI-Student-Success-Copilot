import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const badResponses: string[] = [];
page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
page.on('response', (response) => { if (response.status() >= 400) badResponses.push(`${response.status()} ${response.url()}`); });
await page.setViewportSize({width: 1280, height: 720});
await page.goto('https://success-copilot-1.preview.emergentagent.com/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click({ force: true });
await page.waitForURL('**/');
await page.getByTestId('dashboard-heading').waitFor();
await page.getByTestId('nav-Students-link').click({ force: true });
await page.getByTestId('student-search-input').fill('Aarav');
await page.getByTestId('student-row-stu-001').click({ force: true });
await page.getByTestId('profile-student-name').waitFor();
await page.screenshot({ path: 'copilot-happy-path.png', fullPage: false });
console.log(JSON.stringify({ errors, badResponses, finalUrl: page.url(), student: await page.getByTestId('profile-student-name').innerText() }));
});
