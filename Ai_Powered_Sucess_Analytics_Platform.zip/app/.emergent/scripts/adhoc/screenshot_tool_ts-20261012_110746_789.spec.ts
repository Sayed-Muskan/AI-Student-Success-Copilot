import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click({ force: true });
await page.getByTestId('dashboard-heading').waitFor({ timeout: 10000 });
for (const text of ['Search workspace', 'Thursday, 24 October 2024', 'Score engine', 'AI Copilot', 'soon']) {
  if (await page.getByText(text, { exact: true }).count()) throw new Error(`${text} is still visible`);
}
await page.screenshot({ path: 'appshell-cleanup.png', fullPage: false });
console.log(JSON.stringify({ context: await page.getByTestId('page-context').innerText(), url: page.url() }));
});
