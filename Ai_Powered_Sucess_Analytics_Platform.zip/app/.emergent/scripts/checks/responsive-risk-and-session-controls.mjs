await page.setViewportSize({ width: 390, height: 844 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click();
await expect(page.getByTestId('app-shell')).toBeVisible();

await page.getByTestId('mobile-menu-button').click();
await expect(page.getByTestId('mobile-sidebar-overlay')).toBeVisible();
await page.getByTestId('nav-Risk-signals-link').click();
await expect(page.getByTestId('mobile-sidebar-overlay')).toHaveCount(0);
await expect(page.getByTestId('risk-signals-page')).toBeVisible();
await expect(page.getByTestId('risk-kpi-grid')).toBeVisible();
await shot('mobile-risk-page');

const firstRow = page.locator('[data-testid="highest-risk-list"] button').first();
await firstRow.click();
await expect(page).toHaveURL(/\/students\/stu-/);
await shot('mobile-student-profile');

await page.getByTestId('mobile-menu-button').click();
await expect(page.getByTestId('mobile-sidebar-overlay')).toBeVisible();
await page.getByTestId('sidebar-close-button').click();
await expect(page.getByTestId('mobile-sidebar-overlay')).toHaveCount(0);
await expect(page.getByTestId('app-sidebar')).not.toBeInViewport();

await page.getByTestId('mobile-menu-button').click();
await expect(page.getByTestId('logout-button')).toBeVisible();
await page.getByTestId('logout-button').click();
await expect(page.getByTestId('login-page')).toBeVisible();
await shot('mobile-logged-out');