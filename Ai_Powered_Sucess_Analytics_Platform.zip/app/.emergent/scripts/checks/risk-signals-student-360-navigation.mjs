await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click();
await expect(page.getByTestId('app-shell')).toBeVisible();
await page.getByTestId('nav-Risk-signals-link').click();
await expect(page.getByTestId('risk-signals-page')).toBeVisible();

const firstRow = page.locator('[data-testid="highest-risk-list"] button').first();
const studentName = await firstRow.locator('[data-testid^="risk-student-name-"]').textContent();
await firstRow.click();

await expect(page).toHaveURL(/\/students\/stu-/);
await expect(page.getByTestId('student-360-page').or(page.locator('body'))).toBeVisible();
await shot('student-360-from-risk');
const bodyText = await page.locator('body').innerText();
if (studentName && !bodyText.includes(studentName.trim())) throw new Error(`Expected ${studentName} on student profile page`);