await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click();
await expect(page.getByTestId('app-shell')).toBeVisible();
await page.getByTestId('nav-Risk-signals-link').click();
await expect(page.getByTestId('risk-signals-page')).toBeVisible();

const scopeKpi = page.getByTestId('risk-kpi-value-profiles-in-scope');
const beforeText = await scopeKpi.textContent();

await page.getByTestId('placement-risk-tab').click();
await expect(page.getByTestId('placement-risk-tab')).toHaveClass(/bg-\[#67e8f9\]/);

await page.getByTestId('risk-department-filter').selectOption('CSE');
await expect(scopeKpi).toHaveText('60');

await page.getByTestId('risk-level-filter').selectOption('Low');
const afterFilterText = await scopeKpi.textContent();
if (afterFilterText === beforeText) throw new Error('KPI did not change after filtering');
await shot('placement-filtered');

// drive risk level filter to a value that yields an empty ranked list and assert empty state renders
await page.getByTestId('risk-department-filter').selectOption('All departments');
await page.getByTestId('risk-level-filter').selectOption('All risk levels');
await expect(scopeKpi).toHaveText('300');