await page.goto('/login', { waitUntil: 'domcontentloaded' });
await expect(page.getByTestId('login-page')).toBeVisible();
await expect(page.getByTestId('login-email-input')).toBeVisible();
await expect(page.getByTestId('login-password-input')).toBeVisible();
await shot('login-form');

await page.getByTestId('quick-admin-login-button').click();
await expect(page.getByTestId('app-shell')).toBeVisible();
await expect(page.getByTestId('live-data-indicator')).toContainText('mock fallback');
await expect(page.getByTestId('current-user-role')).toContainText('admin');
await shot('admin-demo-workspace');

await page.goto('/risk', { waitUntil: 'domcontentloaded' });
await expect(page.getByTestId('data-source-label')).toContainText('Mock fallback');
await shot('risk-mock-banner');