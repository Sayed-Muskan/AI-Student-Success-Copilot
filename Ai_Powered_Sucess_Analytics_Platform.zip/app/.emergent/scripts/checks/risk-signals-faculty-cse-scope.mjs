await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-faculty-login-button').click();
await expect(page.getByTestId('app-shell')).toBeVisible();
await expect(page.getByTestId('current-user-role')).toContainText('faculty');
await expect(page.getByTestId('current-user-role')).toContainText('CSE');

await page.getByTestId('nav-Risk-signals-link').click();
await expect(page.getByTestId('risk-signals-page')).toBeVisible();
await expect(page.getByTestId('risk-kpi-value-profiles-in-scope')).toHaveText('60');
await expect(page.getByTestId('risk-department-filter')).toBeDisabled();
await expect(page.getByTestId('risk-heatmap-label-cse')).toBeVisible();
await expect(page.getByTestId('risk-heatmap-label-ece')).toHaveCount(0);

const metaTexts = await page.locator('[data-testid^="risk-student-meta-"]').allTextContents();
for (const text of metaTexts) {
  if (!text.includes('CSE')) throw new Error(`Non-CSE department leaked into faculty ranked list: ${text}`);
}
await shot('faculty-cse-scope');