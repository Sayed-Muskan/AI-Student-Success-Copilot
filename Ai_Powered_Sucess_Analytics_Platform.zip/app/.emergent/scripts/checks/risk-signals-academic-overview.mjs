await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.getByTestId('quick-admin-login-button').click();
await expect(page.getByTestId('app-shell')).toBeVisible();

await page.getByTestId('nav-Risk-signals-link').click();
await expect(page.getByTestId('risk-signals-page')).toBeVisible();
await expect(page.getByTestId('academic-risk-tab')).toHaveClass(/bg-\[#c4b5fd\]/);
await expect(page.getByTestId('risk-kpi-grid')).toBeVisible();
await expect(page.getByTestId('risk-kpi-value-profiles-in-scope')).toHaveText('300');
await expect(page.getByTestId('risk-trend-chart')).toBeVisible();
await expect(page.getByTestId('risk-posture-donut')).toBeVisible();
await expect(page.getByTestId('risk-command-heatmap')).toBeVisible();
await expect(page.getByTestId('risk-heatmap-label-cse')).toBeVisible();
await expect(page.getByTestId('highest-risk-list')).toBeVisible();
const rankedRows = page.locator('[data-testid="highest-risk-list"] button');
await expect(rankedRows.first()).toBeVisible();
await shot('risk-academic-overview');